package com.bda.projectpulse.models

enum class UserRole {
    ADMIN,
    MANAGER,
    USER
} 