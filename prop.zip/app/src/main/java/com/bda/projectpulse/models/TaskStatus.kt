package com.bda.projectpulse.models

enum class TaskStatus {
    TODO,
    IN_PROGRESS,
    IN_REVIEW,
    APPROVED,
    REJECTED
} 