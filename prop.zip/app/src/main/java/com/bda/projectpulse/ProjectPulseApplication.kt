package com.bda.projectpulse

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class ProjectPulseApplication : Application() 