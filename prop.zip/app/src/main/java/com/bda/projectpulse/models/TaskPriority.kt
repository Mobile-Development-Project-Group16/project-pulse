package com.bda.projectpulse.models

enum class TaskPriority {
    LOW,
    MEDIUM,
    HIGH,
    URGENT
} 